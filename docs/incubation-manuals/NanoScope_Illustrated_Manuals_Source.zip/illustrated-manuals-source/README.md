# Illustrated manual sources

Final plans and original screenshot pixels for the 2026-09-29 documentation edition, targeting NanoScope 40.15.59. These are documentation assets, not study datasets.

The renderer uses Python with ReportLab, Pillow and pypdf. It resolves screenshots relative to this folder and writes to `rendered-output/`. Set `FONT` near the top of `build_illustrated.py` to a local directory containing DejaVuSans.ttf, DejaVuSans-Bold.ttf and DejaVuSans-Oblique.ttf. The supplied font path is the build environment used for this edition.

Run `python3 build_illustrated.py --metal all` (or Zn, Cu, Acid). Inspect rendered PDF pages after edits. The final JSON plans already include the current profile launcher and shared main-app curation path; no application, recording or model is needed to rebuild them.

Screen metadata records original capture paths and provenance. The renderer resolves each image to the matching bundled basename. It draws labels and crop windows over original pixels. Older retained captures are explicitly dated in the plans/captions. Acid example screens use a synthetic fixture.
