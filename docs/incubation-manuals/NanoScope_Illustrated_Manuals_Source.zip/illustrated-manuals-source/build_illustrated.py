"""Build accessible vector-callout manuals around unaltered NanoScope captures."""
from pathlib import Path
from xml.sax.saxutils import escape
import json, re, hashlib, argparse
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
from pypdf import PdfReader, PdfWriter

ROOT=Path(__file__).resolve().parent
WORK=Path(__file__).resolve().parent
OUT=ROOT/'rendered-output'
FONT=Path('/Users/abrahamcampos/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/libreoffice-headless/libreoffice/LibreOfficeDev.app/Contents/Resources/fonts/truetype')
for family,filename in [('D','DejaVuSans.ttf'),('DB','DejaVuSans-Bold.ttf'),('DI','DejaVuSans-Oblique.ttf')]:
    pdfmetrics.registerFont(TTFont(family,str(FONT/filename)))
pdfmetrics.registerFontFamily('D',normal='D',bold='DB',italic='DI',boldItalic='DB')
W,H=landscape(A4)
INK=colors.HexColor('#173345'); MUTED=colors.HexColor('#536672'); TEAL=colors.HexColor('#086d77')
ORANGE=colors.HexColor('#b64e13'); PALE=colors.HexColor('#edf5f6'); LINE=colors.HexColor('#ccdadd')
AUDIT=[]

def clean(s):
    return str(s).replace('\u2011','-').replace('\u2212','-').replace('\u200b','')

def para(s,size=10,leading=None,color=INK,bold=False):
    return Paragraph(clean(s),ParagraphStyle('p',fontName='DB' if bold else 'D',fontSize=size,leading=leading or size*1.4,textColor=color,spaceAfter=0,splitLongWords=1))

def text(c,s,x,y,width,size=10,leading=None,color=INK,bold=False):
    p=para(s,size,leading,color,bold); _,h=p.wrap(width,2000)
    p.drawOn(c,x,y-h)
    return y-h

def footer(c,metal,n,ident=''):
    c.setStrokeColor(LINE); c.setLineWidth(.5); c.line(28,30,W-28,30)
    c.setFont('D',8); c.setFillColor(MUTED)
    c.drawString(28,17,f'NanoScope 40.15.59  |  {metal} incubation study  |  29 September 2026')
    c.drawRightString(W-28,17,f'{ident}   /   {n}')

def header(c,metal,ident,title,kicker):
    c.setFillColor(TEAL); c.rect(0,H-7,W,7,fill=1,stroke=0)
    c.setFont('DB',9); c.setFillColor(TEAL); c.drawString(28,H-29,f'{metal.upper()} INCUBATION  /  {ident}')
    size=23
    while pdfmetrics.stringWidth(clean(title),'DB',size)>W-56: size-=.5
    c.setFont('DB',size); c.setFillColor(INK); c.drawString(28,H-62,clean(title))
    text(c,escape(kicker),28,H-74,W-56,9.2,color=MUTED)

def load_screens():
    screens={}; mapping={}
    def addmap(d):
        for k,v in d.items():
            if k in ('zn','cu') and isinstance(v,dict):mapping.update(v)
            else:mapping[k]=v
    for f in sorted((WORK/'screens').glob('*screens.json')):
        d=json.loads(f.read_text())
        for s in d.get('screens',[]):
            for panel in s.get('panels', [s]):
                panel['image'] = str(WORK / 'screens' / Path(panel['image']).name)
            screens[s['key']]=s
        addmap(d.get('page_map',{})); addmap(d.get('page_mapping',{}))
    for f in (WORK/'screens').glob('*mapping*.json'):
        d=json.loads(f.read_text()); addmap(d.get('page_map',d))
    return screens,mapping

def union(*rects):
    x=min(r[0] for r in rects); y=min(r[1] for r in rects)
    return [x,y,max(r[0]+r[2] for r in rects)-x,max(r[1]+r[3] for r in rects)-y]

def aliases(s):
    for p in s.get('panels',[s]):
        t=p.setdefault('targets',{})
        for dest,srcs in {
            'appearance_fonts':['font','title_size','axis_size','tick_size'],
            'appearance_controls':['grid','line_width','marker_size'],
            'style_scroll':['appearance_save_preset'],
            'panel_labels':['panel','label_title','x_label','y_label'],
            'series_colors':['color_control','color_choose'],
            'prev_next':['previous','next'], 'accept_reject':['accept','reject'],
            'event_waveform':['waveform'], 'manual_study_action':['manual_menu']
        }.items():
            if dest not in t and all(k in t for k in srcs):t[dest]=union(*(t[k] for k in srcs))
    return s

def callouts(c,targets,steps,ox,oy,scale,ih):
    used=[]
    for st in steps:
        key=st['target_key']
        if key not in targets: continue
        rx,ry,rw,rh=targets[key]
        x,y=ox+rx*scale,oy+(ih-ry-rh)*scale
        w,h=rw*scale,rh*scale
        c.setStrokeColor(ORANGE); c.setLineWidth(1.2)
        c.roundRect(x-1,y-1,w+2,h+2,2,stroke=1,fill=0)
        cx=max(ox-8,x-8); cy=y+h+1
        while any(abs(cx-px)<20 and abs(cy-py)<20 for px,py in used):cy-=22
        used.append((cx,cy))
        c.setStrokeColor(ORANGE);c.setLineWidth(1);c.line(cx+6,cy-4,x+1,y+h-1)
        c.setFillColor(ORANGE);c.setStrokeColor(colors.white);c.setLineWidth(1.4);c.circle(cx,cy,8.5,fill=1,stroke=1)
        c.setFillColor(colors.white);c.setFont('DB',9.5);c.drawCentredString(cx,cy-3.3,str(st['n']))

def draw_screen(c,s,steps,x,top,width,height,pageid):
    available=s.get('panels',[s])
    relevant=[p for p in available if any(st['target_key'] in p.get('targets',{}) for st in steps)]
    panels=sorted(relevant or available,key=lambda p:min([st['n'] for st in steps if st['target_key'] in p.get('targets',{})] or [999]))
    captions=19*len(panels); gap=10*(len(panels)-1)
    common=min(width/max(p['width'] for p in panels),(height-captions-gap)/sum(p['height'] for p in panels))
    y=top
    seen=set()
    for i,p in enumerate(panels):
        scale=common; pw=p['width']*scale;ph=p['height']*scale
        ix=x+(width-pw)/2;iy=y-ph
        c.setFillColor(colors.white);c.setStrokeColor(LINE);c.roundRect(ix-2,iy-2,pw+4,ph+4,3,fill=1,stroke=1)
        if 'source_size' in p:
            # Place a genuine screenshot through a PDF clipping window. Source pixels
            # remain unchanged; callouts refer to controls visible in this crop.
            sx,sy,sw,sh=p['source_rect'];fw,fh=p['source_size']
            c.saveState();clip=c.beginPath();clip.rect(ix,iy,pw,ph);c.clipPath(clip,stroke=0,fill=0)
            c.drawImage(p['image'],ix-sx*scale,iy-(fh-sy-sh)*scale,width=fw*scale,height=fh*scale,mask='auto')
            c.restoreState()
        else:
            c.drawImage(p['image'],ix,iy,width=pw,height=ph,mask='auto')
        matched=[st for st in steps if st['target_key'] in p.get('targets',{}) and st['n'] not in seen]
        for st in matched:
            r=p['targets'][st['target_key']]
            assert r[0]>=-1 and r[1]>=-1 and r[0]+r[2]<=p['width']+1 and r[1]+r[3]<=p['height']+1,(pageid,st,r,p['width'],p['height'])
            seen.add(st['n'])
        callouts(c,p.get('targets',{}),matched,ix,iy,scale,p['height'])
        caption=p.get('caption',s.get('caption','Actual NanoScope controls. Numbers match the actions at right.'))
        text(c,escape(caption),x,iy-7,width,8.0,leading=10,color=MUTED)
        AUDIT.append(dict(page=pageid,image=p['image'],scale=round(scale,3),targets=[st['n'] for st in matched]))
        y=iy-19-10
    missing={s['n'] for s in steps}-seen
    assert not missing,(pageid,'unmapped callouts',missing,[(s['n'],s['target_key']) for s in steps])
    return y

def draw_tutorial(c,metal,p,n,s):
    header(c,metal,p['id'],p['title'],p.get('kicker','Follow the numbered controls and actions.'))
    c.setFont('DB',9);c.setFillColor(TEAL);c.drawString(553,H-108,'DO THIS IN NANOSCOPE')
    body_top=H-126; bottom=47; right_x=553;right_w=W-28-right_x
    settings=p.get('settings',[])
    settings_h=0
    if settings:
        sethtml='<b>Values for this step</b><br/>'+'<br/>'.join(f'<b>{escape(clean(a))}:</b> {escape(clean(b))}' for a,b in settings)
        sp=para(sethtml,9.1,12)
        _,settings_h=sp.wrap(492,2000);settings_h+=17
    draw_screen(c,s,p['steps'],32,body_top+10,490,body_top-bottom-settings_h,p['id'])
    if settings:
        c.setFillColor(PALE);c.roundRect(28,bottom,500,settings_h,5,fill=1,stroke=0)
        sp.drawOn(c,36,bottom+8)
    def heights(size):
        out=[]
        for st in p['steps']:
            pa=para(f"<b>{escape(st['title'])}</b><br/>{escape(st['text'])}",size,size*1.38)
            _,h=pa.wrap(right_w-25,2000);out.append((st,pa,h))
        notes=[]
        for lab,val in [('Keep in mind',p.get('note','')),('You should see',p.get('expected',''))]:
            if val:
                pa=para(f'<b>{lab}</b><br/>{escape(val)}',size-.4,(size-.4)*1.35,color=MUTED if lab=='Keep in mind' else TEAL)
                _,h=pa.wrap(right_w,2000);notes.append((pa,h))
        return out,notes,sum(v[2]+11 for v in out)+sum(v[1]+11 for v in notes)
    size=10.3
    items,notes,total=heights(size)
    while total>body_top-bottom and size>8.9:
        size-=.2;items,notes,total=heights(size)
    assert total<=body_top-bottom,(p['id'],'text overflow',total,body_top-bottom)
    y=body_top
    for st,pa,h in items:
        c.setFillColor(ORANGE);c.circle(right_x+8,y-7,8,fill=1,stroke=0)
        c.setFillColor(colors.white);c.setFont('DB',9);c.drawCentredString(right_x+8,y-10,str(st['n']))
        pa.drawOn(c,right_x+25,y-h);y-=h+11
    for pa,h in notes:pa.drawOn(c,right_x,y-h);y-=h+11
    AUDIT.append(dict(page=p['id'],step_font=round(size,2),text_bottom=round(y,1)))
    footer(c,metal,n,p['id']);c.showPage()

def cover(c,metal,plan):
    c.setFillColor(TEAL);c.rect(0,0,W,7,fill=1,stroke=0)
    c.setFont('DB',11);c.setFillColor(TEAL);c.drawString(38,H-48,'NANOSCOPE  /  ILLUSTRATED WORKFLOW')
    c.setFont('DB',38);c.setFillColor(INK);c.drawString(38,H-113,f'{metal} incubation study')
    y=text(c,'Raw recordings to reviewed events and publication figures',38,H-140,W-76,18,24)
    y=text(c,'Follow one page at a time. Orange numbers on each screenshot match the numbered actions beside it. Numbers restart on the next page.',38,y-24,700,12.5,18)
    cols=[('01','Prepare','Identify each ABF and apply the exact recording recipe.'),('02','Review','Check detections; optionally edit individual events or whole clusters.'),('03','Analyze & style','Recompute, make the complete figure set, style it and save.')]
    xx=38; cy=H-267
    for num,title,body in cols:
        c.setFillColor(PALE);c.roundRect(xx,cy-119,240,119,7,fill=1,stroke=0)
        c.setFont('DB',11);c.setFillColor(TEAL);c.drawString(xx+14,cy-23,num)
        text(c,title,xx+14,cy-35,212,14,bold=True)
        text(c,body,xx+14,cy-59,212,10.7,15)
        xx+=258
    y=H-405
    detector={'Zn':'The Zn reference uses the supplied student. Native model-free detection is available for a separately documented analysis.',
        'Cu':'The Cu reference uses model-free Schmitt detection. No trained model is required.',
        'Acid':'The Acid reference uses calibrated pulse/level CUSUM and frozen reference families. No trained model is required.'}[metal]
    text(c,f'<b>Choose your route.</b> Keep the automatic event decisions to reproduce the saved reference. For a curated analysis, use a separate workspace copy and rerun the affected downstream stages.',38,y,W-76,11,16)
    text(c,detector,38,y-46,W-76,10.5,15)
    text(c,'Launcher and shared curation views are refreshed for build 40.15.59. Unchanged reference illustrations retain their capture dates. Examples show saved or explicitly labeled fixture data; this documentation update did not rerun the scientific studies.',38,y-82,W-76,9.2,13,color=MUTED)
    footer(c,metal,1,'START');c.showPage()

def contents(c,metal,plan):
    header(c,metal,'MAP','Find the next step','Use the page IDs in the text to find the corresponding walkthrough or recipe.')
    pages=plan['pages']; groups=[pages[:(len(pages)+1)//2],pages[(len(pages)+1)//2:]]
    for col,items in enumerate(groups):
        x=28+col*400;y=H-116
        for p in items:
            c.setFont('DB',9);c.setFillColor(TEAL);c.drawString(x,y,p['id'])
            yy=text(c,escape(p['title']),x+46,y+8,303,9.5,12)
            c.setFont('D',9);c.setFillColor(MUTED);c.drawRightString(x+377,y,str(4+pages.index(p)))
            y=min(y-25,yy-13)
    text(c,'<b>First, see the workspace overview on page 3.</b> Recipes and checkpoints follow the walkthrough: exact file names, scientific settings, counts and the figure inventory. Use the PDF bookmarks to jump directly to any walkthrough or recipe.',28,92,W-56,10,14)
    footer(c,metal,2,'MAP');c.showPage()

def orientation(c,metal,s):
    header(c,metal,'ORIENTATION','Find your way around the workspace','Study controls and result views. Use the following close-ups for the current launcher and shared event-curation steps.')
    steps=[dict(n=i+1,target_key=k) for i,k in enumerate(['toolbar','stages','controls','results'])]
    s={**s,'caption':s.get('caption','Workspace overview. Numbers match the four descriptions below.')}
    draw_screen(c,s,steps,38,H-116,W-76,320,'ORIENTATION')
    labels=[('Choose the recording','The top toolbar creates, opens and saves the workspace; the selector chooses the active recording.'),('Choose the stage','The six tabs run from Sources to Figures. If a tab is hidden, use the small arrow at the bottom of the tab strip.'),('Set and run','Enter values and click the stage button here. Scroll inside this panel to reach the lower controls.'),('Inspect the result','Switch among the trace, tables, figures and methods here. These tabs display the saved results.')]
    for i,(title,body) in enumerate(labels):
        x=28+i*199
        c.setFillColor(ORANGE);c.circle(x+8,135,8,fill=1,stroke=0);c.setFillColor(colors.white);c.setFont('DB',9);c.drawCentredString(x+8,132,str(i+1))
        text(c,escape(title),x+22,143,174,10.2,bold=True)
        text(c,escape(body),x,119,183,9.3,13)
    footer(c,metal,3,'ORIENTATION');c.showPage()

def table(rows,headers=None,compact=False):
    n=len(headers or rows[0]);total=W-72
    if n==2: widths=[total*.28,total*.72]
    elif n==3: widths=[total*.17,total*.53,total*.30]
    elif n==6: widths=[total*.30]+[total*.14]*5
    else:widths=[total/n]*n
    if headers and 'Saved filename' in headers:widths=[total*.10,total*.27,total*.63]
    size=(8.6 if compact else 9.2) if n<5 else 8.5
    data=[]
    if headers:data.append([para(escape(clean(v)),size,size*1.3,color=colors.white,bold=True) for v in headers])
    def cell(v):
        s=escape(clean(v))
        if str(v).startswith('log_dwell,'):s=s.replace(',',', ')
        return para(s,size,size*1.34)
    data += [[cell(v) for v in row] for row in rows]
    t=Table(data,colWidths=widths,repeatRows=1 if headers else 0,hAlign='LEFT')
    padding=4 if compact else 7
    style=[('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),padding),('BOTTOMPADDING',(0,0),(-1,-1),padding),('LINEBELOW',(0,0),(-1,-1),.4,LINE)]
    if headers:style.extend([('BACKGROUND',(0,0),(-1,0),TEAL),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE])])
    else:style.append(('ROWBACKGROUNDS',(0,0),(-1,-1),[PALE,colors.white]))
    t.setStyle(TableStyle(style));return t

def appendices(metal,plan,path,offset):
    state={'title':'Recipes and checkpoints','id':'REFERENCE'}; story=[]; starts={}
    class SetHeader(Spacer):
        def __init__(self,a):super().__init__(1,1);self.a=a
        def draw(self):
            state.update(title=self.a['title'],id=self.a['id']);starts[self.a['id']]=self.canv.getPageNumber()+offset
    for ai,a in enumerate(plan['appendices']):
        if ai:story.append(PageBreak())
        story.append(SetHeader(a))
        story.append(para(escape(a['id']+' / '+a['title']),21,27,bold=True));story.append(Spacer(1,12))
        if a.get('subtitle'):story.extend([para(escape(a['subtitle']),11,16,color=MUTED),Spacer(1,13)])
        for s in a.get('paragraphs',[]):story.extend([para(escape(s),10.5,15),Spacer(1,10)])
        if a.get('settings'):story.extend([table(a['settings'],['Control / checkpoint','Value']),Spacer(1,12)])
        if a.get('rows'):story.extend([table(a['rows'],a.get('columns'),compact=a['id']=='A09'),Spacer(1,12)])
        for t in a.get('tables',[]):
            sub=para(escape(t['title']),12,17,bold=True);sub.keepWithNext=True
            gap=Spacer(1,6);gap.keepWithNext=True
            story.extend([sub,gap,table(t['rows'],t.get('headers')),Spacer(1,14)])
        for item in a.get('items',[]):
            if isinstance(item,dict):
                label='<b>'+escape(str(item.get('title','')))+':</b> '+escape(str(item.get('text','')))
            else:label=escape(str(item))
            story.extend([para('• '+label,10.0 if a['id']=='H' else 10.4,13.8 if a['id']=='H' else 15),Spacer(1,6 if a['id']=='H' else 9)])
        for s in a.get('notes',[]):story.extend([para(escape(s),10.5,15),Spacer(1,10)])
    def onpage(c,doc):
        c.setFillColor(TEAL);c.setFont('DB',9);c.drawString(36,H-28,f'{metal.upper()} INCUBATION  /  RECIPES & CHECKPOINTS')
        footer(c,metal,doc.page+offset,'REFERENCE')
    class RecipeDoc(SimpleDocTemplate):
        def afterPage(self):
            label=state['id']+' / '+state['title']
            sz=8
            while pdfmetrics.stringWidth(clean(label),'D',sz)>440:sz-=.25
            self.canv.setFont('D',sz);self.canv.setFillColor(MUTED);self.canv.drawRightString(W-36,H-28,clean(label))
    doc=RecipeDoc(str(path),pagesize=(W,H),leftMargin=36,rightMargin=36,topMargin=47,bottomMargin=47,title=f'NanoScope {metal} illustrated incubation guide - recipes',author='NanoScope workflow documentation')
    doc.build(story,onFirstPage=onpage,onLaterPages=onpage)
    return starts

def build(metal,allow_missing=False):
    plan=json.loads((WORK/f'{metal.lower()}-plan.json').read_text());screens,mapping=load_screens()
    OUT.mkdir(parents=True,exist_ok=True)
    core=WORK/f'{metal}-walkthrough.pdf';extra=WORK/f'{metal}-recipes.pdf'
    c=canvas.Canvas(str(core),pagesize=(W,H));c.setTitle(f'NanoScope {metal} Incubation - Illustrated Reproduction Manual');c.setAuthor('NanoScope workflow documentation')
    cover(c,metal,plan);contents(c,metal,plan);orientation(c,metal,screens[plan.get('orientation_key','workspace_overview')])
    missed=[]
    for i,p in enumerate(plan['pages']):
        selected=p['screen_key'] if p['screen_key'].startswith(('current_','acid_')) else mapping.get(p['id'],p['screen_key'])
        if isinstance(selected,dict):
            key=selected.get('screen_key',selected.get('key',p['screen_key']))
            if 'targets' in selected:
                for st in p['steps']:st['target_key']=selected['targets'].get(st['target_key'],st['target_key'])
        else:key=selected
        if key not in screens or (allow_missing and key=='analysis_menu'):
            if not allow_missing:raise KeyError((p['id'],key))
            header(c,metal,p['id'],p['title'],'DRAFT: screenshot pending');footer(c,metal,i+4,p['id']);c.showPage();missed.append(key);continue
        draw_tutorial(c,metal,p,i+4,aliases(screens[key]))
    c.save()
    starts=appendices(metal,plan,extra,3+len(plan['pages']))
    writer=PdfWriter();writer.append(str(core));writer.append(str(extra))
    writer.add_outline_item('Start here',0);writer.add_outline_item('Workflow map',1)
    writer.add_outline_item('Workspace overview',2)
    for i,p in enumerate(plan['pages']):writer.add_outline_item(p['id']+' - '+p['title'],i+3)
    for a in plan['appendices']:writer.add_outline_item(a['id']+' - '+a['title'],starts[a['id']]-1)
    writer.add_metadata({'/Title':f'NanoScope {metal} Incubation - Illustrated Reproduction Manual','/Author':'NanoScope workflow documentation','/Subject':'Actual GUI screenshots, numbered instructions, recipes and scientific checkpoints'})
    dest=OUT/f'NanoScope_{metal}_Incubation_Illustrated_Manual.pdf';writer.write(str(dest))
    record=dict(file=str(dest),pages=len(writer.pages),walkthrough_pages=len(plan['pages']),appendix_starts=starts,missing=missed,sha256=hashlib.sha256(dest.read_bytes()).hexdigest())
    (WORK/f'{metal}-layout.json').write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--metal',choices=['Zn','Cu','Acid','all'],default='all');ap.add_argument('--allow-missing',action='store_true');args=ap.parse_args()
    for metal in (['Zn','Cu','Acid'] if args.metal=='all' else [args.metal]):build(metal,args.allow_missing)
    (WORK/'layout-audit.json').write_text(json.dumps(AUDIT,indent=2))
